
// var http = require('http');
// var server = http.createServer();
 
// function mensaje(petic, resp) {
// 	resp.writeHead(200, {'content-type': 'text/plain'});
// 	resp.write('Hola Mundo');
// 	resp.end();
// }
// server.on('request', mensaje);
 
// server.listen(3000, function () {
//   	console.log('La Aplicación está funcionando en el puerto 3000');
// });

var express = require('express'); // Web Framework
var app = express();
var sql = require('mssql'); // MS Sql Server client

// Connection string parameters.
var sqlConfig = {
    user: 'user',
    password: 'Cerezo.2022',
    server: '192.168.1.200',
    database: 'GAECTI_PRU',
    encrypt: false
}

// Start server and listenn on http://localhost:8081/
var server = app.listen(8081, function () {
    var host = server.address().address
    var port = server.address().port

    console.log("app listening at http://%s:%s", host, port)
});


app.post('/users', (request, response) => {
    sqlConfig.query('INSERT INTO plataforma SET ?', request.body, (error, result) => {
        if (error) throw error;
 
        response.status(201).send(`User added with ID: ${result.insertId}`);
    });

    
});

