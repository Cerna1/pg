var express = require(`experss`)
var app = express()

app.use(`/`,(req,res) => res.send("hola cdfdh"))

app.listen(3000,() => console.log("escuchando en el el jdjd"))